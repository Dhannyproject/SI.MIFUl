<?php
echo $this->extend('template/index');
echo $this->section('content');
?>
<p>content Siswa</p>
<?php
echo $this->endsection();
