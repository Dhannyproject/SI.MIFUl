<?php
echo $this->extend('template/index');
echo $this->section('content');
?>
<p>content Alumni</p>
<?php
echo $this->endsection();
